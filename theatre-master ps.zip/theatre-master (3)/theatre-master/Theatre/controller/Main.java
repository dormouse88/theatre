package controller;

public class Main {
	public static void main(String[] args) {
		Engine engine = new Engine();
		engine.run();
	}
}
